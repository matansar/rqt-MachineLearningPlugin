# define configure parameters for the use of other python code
class Configure:
    TRAINING = "trainings";
    POSITIVE = "positives";
    NEGATIVE = "negatives";
    POSITIVE_LABEL = 1
    NEGATIVE_LABEL = 0

# for bold text on result
class Style:
    BOLD = '\033[1m'
    END = '\033[0m'